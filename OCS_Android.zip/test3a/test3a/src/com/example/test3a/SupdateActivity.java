package com.example.test3a;

import java.io.InputStream;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HTTP;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class SupdateActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_supdate);
		Bundle extras = getIntent().getExtras();
		final String userid = extras.getString("UserID");
		final String UserName = extras.getString("UserName");

		TextView tv1 = (TextView) findViewById(R.id.supdateview1);
		TextView tv2 = (TextView) findViewById(R.id.supdateview2);

		tv1.setText(userid);
		tv2.setText(UserName);

		Button btnUpdate = (Button) findViewById(R.id.Updatebutton);
		final String url = "http://130.86.108.80:49902/api/Student/";

		btnUpdate.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				HttpClient httpclient = new DefaultHttpClient();
				HttpResponse response;
				JSONObject json = new JSONObject();
				InputStream content = null;
				HttpPost post = new HttpPost(url);

				try {
					EditText myOutputBox1 = (EditText) findViewById(R.id.UpdateText1);
					String major = myOutputBox1.getText().toString();
					EditText myOutputBox2 = (EditText) findViewById(R.id.UpdateText2);
					String email = myOutputBox2.getText().toString();
					EditText myOutputBox3 = (EditText) findViewById(R.id.UpdateText3);
					String contact = myOutputBox3.getText().toString();

					json.put("StudentID", userid);
					json.put("StudentName", UserName);
					json.put("StudentMajor", major);
					json.put("StudentEmail", email);
					json.put("StudentPhone", contact);

					StringEntity se;
					se = new StringEntity(json.toString());

					se.setContentType(new BasicHeader(HTTP.CONTENT_TYPE,
							"application/json"));
					post.setEntity(se);
					response = httpclient.execute(post);
					if (response != null) {
						AlertDialog.Builder aDialog = new AlertDialog.Builder(
								SupdateActivity.this);
						aDialog.setTitle("Done");
						aDialog.setMessage("Your profile has been updated");
						aDialog.setNeutralButton("OK",
								new DialogInterface.OnClickListener() {

									@Override
									public void onClick(DialogInterface dialog,
											int which) {
										// TODO Auto-generated method stub
										Intent newIntent = new Intent(
												SupdateActivity.this,
												ShomeActivity.class);
										newIntent.putExtra("UserID", userid);
										startActivity(newIntent);
									}
								});
						aDialog.show();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

			}
		});

	}

}
