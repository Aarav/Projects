package com.example.test3a;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HTTP;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class AjobActivity extends Activity {

	@SuppressWarnings("unused")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_ajob);

		Bundle extras = getIntent().getExtras();
		final String userid = extras.getString("UserID");
		int jid = extras.getInt("JOBD");
		String url = "http://130.86.108.80:49902/api/ApplyForJob/" + jid;
		try {
			HttpClient httpclient = new DefaultHttpClient();
			HttpResponse response;
			InputStream content = null;
			HttpGet get = new HttpGet(url);
			response = httpclient.execute(get);

			if (response != null) {

				content = response.getEntity().getContent();

				BufferedReader br = new BufferedReader(new InputStreamReader(
						content));

				StringBuilder sb = new StringBuilder();
				String line = null;

				try {
					while ((line = br.readLine()) != null) {
						sb.append(line + "\n");
					}
				} catch (IOException e) {
					e.printStackTrace();
				} finally {
					try {
						content.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				JSONArray jarr = new JSONArray(sb.toString());
				JSONObject json = jarr.getJSONObject(0);

				TextView mytext1 = (TextView) findViewById(R.id.ajidg); // student
																		// id
				TextView mytext2 = (TextView) findViewById(R.id.ajig); // job id
				TextView mytext3 = (TextView) findViewById(R.id.ajobg); // job
																		// name
				TextView mytext4 = (TextView) findViewById(R.id.ainterestg); // interest
																				// group
																				// name
				TextView mytext5 = (TextView) findViewById(R.id.acomg); // company
																		// name
				TextView mytext6 = (TextView) findViewById(R.id.desc); // description
				TextView mytext7 = (TextView) findViewById(R.id.acoidg); // co
																			// id
				TextView mytext8 = (TextView) findViewById(R.id.apostg); // creation
																			// date

				mytext1.setText(userid);
				mytext2.setText(json.getString("JobID"));
				mytext3.setText(json.getString("JobName"));
				mytext4.setText(json.getString("InterestName"));
				mytext5.setText(json.getString("CompanyName"));
				mytext6.setText(json.getString("Description"));
				mytext7.setText(json.getString("COID"));
				mytext8.setText(json.getString("CreationDate"));

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		Button btnapp = (Button) findViewById(R.id.butapp);

		btnapp.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				TextView mytext1 = (TextView) findViewById(R.id.ajidg); // student
																		// id
				TextView mytext2 = (TextView) findViewById(R.id.ajig); // job id
				TextView mytext3 = (TextView) findViewById(R.id.ajobg); // job
																		// name
				TextView mytext4 = (TextView) findViewById(R.id.ainterestg); // interest
																				// group
																				// name
				TextView mytext5 = (TextView) findViewById(R.id.acomg); // company
																		// name
				TextView mytext6 = (TextView) findViewById(R.id.desc); // description
				TextView mytext7 = (TextView) findViewById(R.id.acoidg); // co
																			// id
				TextView mytext8 = (TextView) findViewById(R.id.apostg); // creation
																			// date

				String stupost = (String) mytext1.getText();
				String jipost = (String) mytext2.getText();
				String jobpost = (String) mytext3.getText();
				String interestpost = (String) mytext4.getText();
				String compost = (String) mytext5.getText();
				String descpost = (String) mytext6.getText();
				String cipost = (String) mytext7.getText();
				String date = (String) mytext8.getText();
				
				JSONObject json = new JSONObject();
				
				try {
					json.put("StudentID", stupost);
					json.put("JobID", jipost);
					
					json.put("JobName", jobpost);
					json.put("InterestName", interestpost);
					
					json.put("CompanyName", compost);
					json.put("Description", descpost);
					
					json.put("COID", cipost);
					json.put("CreationDate", date);
					
					String url = "http://130.86.108.80:49902/api/ApplyForJob/";
					
					HttpClient httpclient = new DefaultHttpClient();
					HttpResponse response;
					
					HttpPost post = new HttpPost(url);
					
					
					StringEntity se;
					se = new StringEntity(json
							.toString());

					se.setContentType(new BasicHeader(
							HTTP.CONTENT_TYPE,
							"application/json"));
					post.setEntity(se);
					response = httpclient.execute(post);
					if(response != null)
					{
						AlertDialog.Builder aDialog = new AlertDialog.Builder(
								AjobActivity.this);
						aDialog.setTitle("Done");
						aDialog.setMessage("Your profile has been updated");
						aDialog.setNeutralButton("OK",
								new DialogInterface.OnClickListener() {

									@Override
									public void onClick(DialogInterface dialog,
											int which) {
										// TODO Auto-generated method stub
										Intent newIntent = new Intent(
												AjobActivity.this,
												ShomeActivity.class);
										newIntent.putExtra("UserID", userid);
										startActivity(newIntent);
									}
								});
						aDialog.show();

						
					}
					
					
					
				} catch (JSONException e) {
					
					e.printStackTrace();
				} catch (UnsupportedEncodingException e) {
					
					e.printStackTrace();
				} catch (ClientProtocolException e) {
					
					e.printStackTrace();
				} catch (IOException e) {
					
					e.printStackTrace();
				}
			}
		});

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_ajob, menu);
		return true;
	}

}
