package com.example.test3a;

import java.io.IOException;
import java.io.InputStream;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HTTP;
import org.json.JSONException;
import org.json.JSONObject;

import android.R.layout;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

public class MainActivitya extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		StrictMode.enableDefaults();
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main_activitya);
		final String url = "http://130.86.108.80:49902/api/Register/";
		final Button btnstart = (Button) findViewById(R.id.button1);
		final Button btnlogin = (Button) findViewById(R.id.button2);

		final int st = 1;

		Thread thread = new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					try {
						try {

							btnstart.setOnClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View v) {
									// TODO Auto-generated method stub
									HttpClient httpclient = new DefaultHttpClient();
									HttpResponse response;
									JSONObject json = new JSONObject();
									InputStream content = null;
									HttpPost post = new HttpPost(url);
									try {
										EditText myOutputBox = (EditText) findViewById(R.id.editText1);
										String username = myOutputBox.getText()
												.toString();
										myOutputBox = (EditText) findViewById(R.id.editText2);
										String password = myOutputBox.getText()
												.toString();
										myOutputBox = (EditText) findViewById(R.id.editText3);
										String cpassword = myOutputBox
												.getText().toString();
										RadioButton rb1 = (RadioButton) findViewById(R.id.radio0);
										RadioButton rb2 = (RadioButton) findViewById(R.id.radio1);

										if (password.equals(cpassword)
												&& rb1.isChecked()) {
											json.put("UserName", username);
											json.put("Password", password);
											json.put("UserType",
													"CompanyOfficial");
											StringEntity se;
											se = new StringEntity(json
													.toString());

											se.setContentType(new BasicHeader(
													HTTP.CONTENT_TYPE,
													"application/json"));
											post.setEntity(se);
											response = httpclient.execute(post);
											/* Checking response */
											if (response != null) {

												InputStream in = response
														.getEntity()
														.getContent();
												Intent newIntent = new Intent(
														getApplicationContext(),
														LoginActivity.class);
												startActivity(newIntent);
											}
										} else if (password.equals(cpassword)
												&& rb2.isChecked()) {
											json.put("UserName", username);
											json.put("Password", password);
											json.put("UserType", "Student");
											StringEntity se;
											se = new StringEntity(json
													.toString());

											se.setContentType(new BasicHeader(
													HTTP.CONTENT_TYPE,
													"application/json"));
											post.setEntity(se);
											response = httpclient.execute(post);
											/* Checking response */
											if (response != null) {

												InputStream in = response
														.getEntity()
														.getContent();
												Intent newIntent = new Intent(
														getApplicationContext(),
														LoginActivity.class);
												startActivity(newIntent);
											}

										}

									} catch (IllegalStateException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									} catch (IOException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									} // Get the data in the entity
									catch (JSONException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
								}
							});

						} catch (Exception e) {
							e.printStackTrace();
						}
						Log.v("afterloop", "afterloop");
					} catch (Exception e) {
						e.printStackTrace();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});

		thread.start();
	}

	public void login(View view) {
		Intent newIntent = new Intent(this, LoginActivity.class);
		startActivity(newIntent);
	}
}
