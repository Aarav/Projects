package com.example.test3a;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class ShomeActivity extends Activity {

	public static final String PREFS = "examplePrefs";
	public String uName = "";

	@SuppressWarnings("unused")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		StrictMode.enableDefaults();
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_shome);
		Bundle extras = getIntent().getExtras();
		String userid = extras.getString("UserID");
		SharedPreferences examplePrefs = getSharedPreferences(PREFS, 0);
		Editor ed = examplePrefs.edit();
		String choo = examplePrefs.getString("StuID", "");

		String urlget1 = "http://130.86.108.80:49902/api/Student/" + userid;

		try {
			HttpClient httpclient = new DefaultHttpClient();
			HttpResponse response;
			JSONObject json = new JSONObject();
			InputStream content = null;
			HttpGet get = new HttpGet(urlget1);
			response = httpclient.execute(get);
			if (response != null) {

				content = response.getEntity().getContent();

				BufferedReader br = new BufferedReader(new InputStreamReader(
						content));

				StringBuilder sb = new StringBuilder();
				String line = null;

				try {
					while ((line = br.readLine()) != null) {
						sb.append(line + "\n");
					}
				} catch (IOException e) {
					e.printStackTrace();
				} finally {
					try {
						content.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				JSONObject jobj = new JSONObject(sb.toString());

				uName = jobj.getString("StudentName");
				final String uID = jobj.getString("StudentID");
				final String uMajor = jobj.getString("StudentMajor");
				final String uEmail = jobj.getString("StudentEmail");
				final String uPhone = jobj.getString("StudentPhone");

				TextView myText1 = (TextView) findViewById(R.id.tView4);
				TextView myText2 = (TextView) findViewById(R.id.tView5);
				TextView myText3 = (TextView) findViewById(R.id.TextView01);
				TextView myText4 = (TextView) findViewById(R.id.TextView02);
				TextView myText5 = (TextView) findViewById(R.id.TextView03);

				myText1.setText(uID);
				myText2.setText(uName);
				myText3.setText(uMajor);
				myText4.setText(uEmail);
				myText5.setText(uPhone);

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		super.onCreateOptionsMenu(menu);
		getMenuInflater().inflate(R.menu.activity_shome, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.item1:
			Bundle extras = getIntent().getExtras();
			String userid = extras.getString("UserID");

			Intent newIntent = new Intent(getApplicationContext(),
					SupdateActivity.class);
			newIntent.putExtra("UserID", userid);
			newIntent.putExtra("UserName", uName);

			startActivity(newIntent);

			return true;
		case R.id.SMJobs:
			Bundle extrass = getIntent().getExtras();
			String Userid = extrass.getString("UserID");

			Intent innew = new Intent(ShomeActivity.this, SjobActivity.class);
			innew.putExtra("UserID", Userid);
			startActivity(innew);

			return true;
		case R.id.SMLogout:
			Intent inew = new Intent(ShomeActivity.this, LoginActivity.class);
			startActivity(inew);
			return true;
			
		case R.id.SMApplied:
			Intent i = new Intent(Intent.ACTION_VIEW, 
				       Uri.parse("http://130.86.108.80:49902/StudentViews/AppliedJobs"));
				startActivity(i);

		}
		return false;
	}

}
