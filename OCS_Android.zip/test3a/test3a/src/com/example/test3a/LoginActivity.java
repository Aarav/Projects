package com.example.test3a;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HTTP;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class LoginActivity extends Activity {

	public static final String PREFS = "examplePrefs";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		StrictMode.enableDefaults();
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		final String url = "http://130.86.108.80:49902/api/Login/";
		Button btnstart = (Button) findViewById(R.id.but1);

		btnstart.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

				HttpClient httpclient = new DefaultHttpClient();
				HttpResponse response;
				JSONObject json = new JSONObject();
				InputStream content = null;
				HttpPost post = new HttpPost(url);
				try {
					EditText myOutputBox = (EditText) findViewById(R.id.eText1);
					String username = myOutputBox.getText().toString();
					myOutputBox = (EditText) findViewById(R.id.eText2);
					String password = myOutputBox.getText().toString();

					json.put("UserName", username);
					json.put("Password", password);

					StringEntity se;
					se = new StringEntity(json.toString());

					se.setContentType(new BasicHeader(HTTP.CONTENT_TYPE,
							"application/json"));
					post.setEntity(se);
					response = httpclient.execute(post);

					if (response != null) {

						content = response.getEntity().getContent();

						BufferedReader br = new BufferedReader(
								new InputStreamReader(content));

						StringBuilder sb = new StringBuilder();
						String line = null;

						try {
							while ((line = br.readLine()) != null) {
								sb.append(line + "\n");
							}
						} catch (IOException e) {
							e.printStackTrace();
						} finally {
							try {
								content.close();
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
						JSONObject jobj = new JSONObject(sb.toString());
						SharedPreferences examplePrefs = getSharedPreferences(
								PREFS, 0);
						Editor ed = examplePrefs.edit();

						String uType = jobj.getString("UserType");
						String uID = jobj.getString("UserID");

						if (uType.equalsIgnoreCase("Student")) {

							Intent newIntent = new Intent(
									getApplicationContext(),
									ShomeActivity.class);
							newIntent.putExtra("UserID", uID);
							ed.putString("StuID", uID);
							ed.commit();
							startActivity(newIntent);
						}
						if (uType.trim().equalsIgnoreCase("CompanyOfficial")) {
/*							Intent newIntent = new Intent(
									getApplicationContext(),
									CHomeActivity.class);
							newIntent.putExtra("UserID", uID);
							ed.putString("COID", uID);
							ed.commit();
							startActivity(newIntent);*/
							String uri = "http://130.86.108.80:49902/COView/COEdit/" + uID;
							Intent i = new Intent(Intent.ACTION_VIEW, 
								       Uri.parse(uri));
								startActivity(i);

						}

					}
				} catch (IllegalStateException e) {

					e.printStackTrace();
				} catch (IOException e) {

					e.printStackTrace();
				} catch (JSONException e) {

					e.printStackTrace();
				}

			}
		});

		final int st = 1;

		Thread thread = new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					try {
						try {

						} catch (Exception e) {
							e.printStackTrace();
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

			}

		});

	}
}
