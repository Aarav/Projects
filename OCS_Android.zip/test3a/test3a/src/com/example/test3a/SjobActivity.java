package com.example.test3a;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

public class SjobActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_sjob);
		final String urlget1 = "http://130.86.108.80:49902/api/ChooseInterestGroups/";

		Bundle extrass = getIntent().getExtras();
		final String Userid = extrass.getString("UserID");
		final Spinner sp = (Spinner) findViewById(R.id.spinner1);
		Button bsearch = (Button) findViewById(R.id.sjobutton);

		bsearch.setOnClickListener(new OnClickListener() {

			@SuppressWarnings("unused")
			@Override
			public void onClick(View v) {
				String txt = sp.getSelectedItem().toString();
				int id = 0;
				if (txt.equalsIgnoreCase("Network"))
					id = 1;
				if (txt.trim().equalsIgnoreCase("Electrical"))
					id = 2;
				if (txt.trim().equalsIgnoreCase("InformationScience"))
					id = 3;
				if (txt.trim().equalsIgnoreCase("Database"))
					id = 4;
				if (txt.trim().equalsIgnoreCase("Analog"))
					id = 5;

				// long id = sp.getSelectedItemId();
				// TODO Auto-generated method stub
				try {
					HttpClient httpclient = new DefaultHttpClient();
					HttpResponse response;
					JSONObject json = new JSONObject();
					InputStream content = null;
					String finurlget1 = urlget1 + id;
					HttpGet get = new HttpGet(finurlget1);
					response = httpclient.execute(get);
					if (response != null) {

						content = response.getEntity().getContent();

						BufferedReader br = new BufferedReader(
								new InputStreamReader(content));

						StringBuilder sb = new StringBuilder();
						String line = null;

						try {
							while ((line = br.readLine()) != null) {
								sb.append(line + "\n");
							}
						} catch (IOException e) {
							e.printStackTrace();
						} finally {
							try {
								content.close();
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
						TableLayout t1 = (TableLayout) findViewById(R.id.tlayout1);
						JSONArray jarr = new JSONArray(sb.toString());
						for (int i = 0; i < jarr.length(); i++) {
							JSONObject joe = jarr.getJSONObject(i);
							final int jid = joe.getInt("JobID");
							int cid = joe.getInt("COID");
							String cname = joe.getString("CompanyName");
							String[] pdate = joe.getString("CreationDate")
									.split("T");
							String pd = pdate[0];
							String jname = joe.getString("JobName");

							TableRow tr = new TableRow(SjobActivity.this);
							// Create text views to be added to the row.
							TextView tv1 = new TextView(SjobActivity.this); // job
																			// id
							TextView tv2 = new TextView(SjobActivity.this); // co
																			// id
							TextView tv3 = new TextView(SjobActivity.this); // cname
							TextView tv4 = new TextView(SjobActivity.this); // jname
							// TextView tv5 = new TextView(SjobActivity.this);
							// //pdate

							createView(tr, tv1, Integer.toString(jid));
							createView(tr, tv2, Integer.toString(cid));
							createView(tr, tv3, cname);
							createView(tr, tv4, jname);
							// createView(tr, tv5, pd);

							Button bt = new Button(SjobActivity.this);

							bt.setText("Apply");
							bt.setId(jid);
							bt.setOnClickListener(new OnClickListener() {

								@Override
								public void onClick(View v) {
									Intent newIntent = new Intent(
											SjobActivity.this,
											AjobActivity.class);
									newIntent.putExtra("UserID", Userid);
									int ji = v.getId();
									newIntent.putExtra("JOBD", ji);
									startActivity(newIntent);

								}
							});

							tr.addView(bt);
							t1.addView(tr);
						}

					}

				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

			private void createView(TableRow tr, TextView tv, String str) {
				tv.setText(str);
				// tv.setLayoutParams(new
				// LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT));

				tr.addView(tv);
			}
		});

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_sjob, menu);
		return true;
	}

}
